
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_objectmerger_bundle = "/bundles/objectmerger/studio/build/0d58056effef/static/js/remoteEntry.js"

      
    