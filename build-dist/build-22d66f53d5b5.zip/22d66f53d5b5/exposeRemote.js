
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_objectmerger_bundle = "/bundles/objectmerger/studio/build/22d66f53d5b5/static/js/remoteEntry.js"

      
    