
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_objectmerger_bundle = "/bundles/objectmerger/studio/build/31cd26dd46d3/static/js/remoteEntry.js"

      
    