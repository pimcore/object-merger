
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_objectmerger_bundle = "/bundles/objectmerger/studio/build/e3dce23edd1f/static/js/remoteEntry.js"

      
    